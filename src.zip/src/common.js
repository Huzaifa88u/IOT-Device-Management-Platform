const API_URLs = {
    SERVER_URL: 'http://localhost:5000'
}